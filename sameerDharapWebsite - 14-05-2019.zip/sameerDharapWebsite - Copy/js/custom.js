$( document ).ready(function() {
$(window).scroll(function(){
  if ($(this).scrollTop() > 500) {
    $('.navbar').addClass('fixed-header');
  } else {
    $('.navbar').removeClass('fixed-header');
  }
});
/*--page scroll to id--*/
$(".navbar-nav a, a.scroll-icon, .footer-nav a").mPageScroll2id({
pageEndSmoothScroll:true,
offset:75,
});
/*js for media-slider slick slider*/
$('.media-slider').slick({
dots: true,
infinite: true,
arrows: false,
speed: 300,
slidesToShow: 3,
slidesToScroll: 1,
centerMode: true,

responsive: [
  {
    breakpoint: 1024,
    settings: {
      slidesToShow: 3,
      slidesToScroll: 1,
      infinite: true,
      dots: true
    }
  },
  {
    breakpoint: 600,
    settings: {
      slidesToShow: 2,
      slidesToScroll: 1
    }
  },
  {
    breakpoint: 480,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1
    }
  }
  // You can unslick at a given breakpoint now by adding:
  // settings: "unslick"
  // instead of a settings object
]

});

/*js for testimonial-slider slick slider*/
$('.testimonial-slider').slick({
dots: true,
infinite: true,
arrows: false,
speed: 300,
slidesToShow: 1,
slidesToScroll: 1,
centerMode: true,

responsive: [
  {
    breakpoint: 1024,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1,
      infinite: true,
      dots: true
    }
  },
  {
    breakpoint: 600,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1
    }
  },
  {
    breakpoint: 480,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1
    }
  }
  // You can unslick at a given breakpoint now by adding:
  // settings: "unslick"
  // instead of a settings object
]

});

/*js for aboutus-slider slick slider*/
$('.aboutus-slider').slick({
dots: true,
infinite: true,
arrows: false,
speed: 300,
slidesToShow: 1,
slidesToScroll: 1,
responsive: [
  {
    breakpoint: 1024,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1,
      infinite: true,
      dots: true
    }
  },
  {
    breakpoint: 600,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1
    }
  },
  {
    breakpoint: 480,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1
    }
  }
  // You can unslick at a given breakpoint now by adding:
  // settings: "unslick"
  // instead of a settings object
]

});
/*credentilal slider ;js*/
$('.carousel').carousel();
/*--animation effect starts from here--*/
AOS.init({
		easing: 'ease-out-back',
		duration: 1000
	});
$('.submit-btn').click(function(){
	$('.alert-success').show().delay(3000).fadeOut();
});

/*step by step form jquery*/
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(evt){

if ($('#name, #email, #msg').val() === '') {
evt.preventDefault();
  $("#name, #email, #msg").addClass("error-msg");
  } else {
  $("#name, #email, #msg").removeClass("error-msg");
    if(animating) return false;
animating = true;

current_fs = $(this).parent();
next_fs = $(this).parent().next();

//show the next fieldset
next_fs.show(); 
//hide the current fieldset with style
current_fs.animate({opacity: 0}, {
  step: function(now, mx) {
    //as the opacity of current_fs reduces to 0 - stored in "now"
    //1. scale current_fs down to 80%
    scale = 1 - (1 - now) * 0.2;
    //2. bring next_fs from the right(50%)
    left = (now * 50)+"%";
    //3. increase opacity of next_fs to 1 as it moves in
    opacity = 1 - now;
    current_fs.css({
      'transform': 'scale('+scale+')',
      'position': 'absolute'
    });
    next_fs.css({'left': left, 'opacity': opacity});
  }, 
  duration: 800, 
  complete: function(){
    current_fs.hide();
    animating = false;
  }, 
  //this comes from the custom easing plugin
  easing: 'easeInOutBack'
});
  }

});

$(".previous").click(function(){
if(animating) return false;
animating = true;

current_fs = $(this).parent();
previous_fs = $(this).parent().prev();

//show the previous fieldset
previous_fs.show(); 
//hide the current fieldset with style
current_fs.animate({opacity: 0}, {
  step: function(now, mx) {
    //as the opacity of current_fs reduces to 0 - stored in "now"
    //1. scale previous_fs from 80% to 100%
    scale = 0.8 + (1 - now) * 0.2;
    //2. take current_fs to the right(50%) - from 0%
    left = ((1-now) * 50)+"%";
    //3. increase opacity of previous_fs to 1 as it moves in
    opacity = 1 - now;
    current_fs.css({'left': left});
    previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
  }, 
  duration: 800, 
  complete: function(){
    current_fs.hide();
    animating = false;
  }, 
  //this comes from the custom easing plugin
  easing: 'easeInOutBack'
});
});


$(".submit").click(function(evt){
if ($('#msg').val().trim().length < 1) {
 evt.preventDefault();
$("#msg").addClass("error-msg");
} else {
//$('.alert-success').show().delay(3000).fadeOut();

$("#name, #email, #msg").removeClass("error-msg");
}
return false;
});
$(".back-btn").click(function(){

$('.success-msg').hide();
$('.first-block').show().css('opacity','1');
document.getElementById("contact-form").reset();
});
});

$('.paroller-outer').paroller({
factorXs: 0.1,
factorSm: 0.1,
factorMd: -0.1,
factorLg: -0.1,
factorXl: -0.1,
factor: -0.1,
type: 'foreground',
direction: 'horizontal'

});

$('.paroller-inner').paroller();

