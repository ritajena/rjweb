(window.webpackJsonp = window.webpackJsonp || []).push([
    [6], {
        242: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function() {
                    function e(e, t) {
                        for (var r = 0; r < t.length; r++) {
                            var a = t[r];
                            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                        }
                    }
                    return function(t, r, a) {
                        return r && e(t.prototype, r), a && e(t, a), t
                    }
                }(),
                n = r(1),
                o = u(n),
                s = u(r(111)),
                i = r(29),
                c = r(12),
                l = u(r(247)),
                p = u(r(318)),
                d = r(8),
                m = r(40);

            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            r(317), r(316), r(315), r(314), r(313);
            var f = function(e) {
                function t(e) {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, t);
                    var r = function(e, t) {
                        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return !t || "object" != typeof t && "function" != typeof t ? e : t
                    }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                    return r.servicesGridWrapper = o.default.createRef(), r.state = {
                        hasComponentLoaded: !1
                    }, r.data = {
                        services: [{
                            accentColor: "#ffff65",
                            textColor: "#000",
                            img: "services-postIt.png",
                            img2x: "services-postIt@2x.png",
                            mainHeader: "User Experience",
                            mainSubHeader: "How users interact",
                            copyHeader: "We are all users.",
                            copyBody: "With over 200 digital projects and counting, we get what users want and need pretty easily. UX is the core to everything we build. In Codigo, we take user research, competitive analysis, wireframes, user flows, content maps very seriously."
                        }, {
                            accentColor: "#eed9dc",
                            textColor: "#000",
                            img: "services-pixCherry.png",
                            img2x: "services-pixCherry@2x.png",
                            mainHeader: "Interface Design",
                            mainSubHeader: "For all the screens in the world",
                            copyHeader: "We live to design.",
                            copyBody: "We have pixel OCD. We keep ourselves constantly inspired with the hype and trends in the design industry to craft gorgeous interactions for your brand."
                        }, {
                            accentColor: "#b3262e",
                            textColor: "#fff",
                            img: "services-letterSeal.png",
                            img2x: "services-letterSeal@2x.png",
                            mainHeader: "Consultancy",
                            mainSubHeader: "For proof-of-concepts",
                            copyHeader: "We can help validate your ideas.",
                            copyBody: "Ready to take the first step? Let us help with a minimum viable product. Tap on our brains and experience to create a semi-product to test the waters. Consult us on user experience, how the product could look like and turn it into a rapid prototype."
                        }, {
                            accentColor: "#1988e8",
                            textColor: "#fff",
                            img: "services-phone.png",
                            img2x: "services-phone@2x.png",
                            mainHeader: "Mobile Development",
                            mainSubHeader: "iOS & Android",
                            copyHeader: "We are Apple & Android friendly.",
                            copyBody: "Native, ReactNative, payment gateway integration, bespoke CMS, consuming APIs from existing sources and all things mobile app relevant. We’ve mostly done it all."
                        }, {
                            accentColor: "#ff8d6e",
                            textColor: "#000",
                            img: "services-laptop.png",
                            img2x: "services-laptop@2x.png",
                            mainHeader: "Web Development",
                            mainSubHeader: "For businesses any shape and size",
                            copyHeader: "We weave front-end magic.",
                            copyBody: "Web portals, microsites (yes, they still exist), web apps - responsive, powered by WordPress or supported by a bespoke CMS. No screen sizes scare us, only IE does."
                        }, {
                            accentColor: "#18a152",
                            textColor: "#fff",
                            img: "services-cogwheels.png",
                            img2x: "services-cogwheels@2x.png",
                            mainHeader: "CMS",
                            mainSubHeader: "Manage your own content",
                            copyHeader: "We give u data.",
                            copyBody: "All bespoke CMS we build comes with a dashboard so you can monitor the activities on your product. Edit or add content at your convenience - we’ll customise everything to your wants and needs."
                        }, {
                            accentColor: "#483245",
                            textColor: "#fff",
                            img: "services-vr.png",
                            img2x: "services-vr@2x.png",
                            mainHeader: "Emerging Tech",
                            mainSubHeader: "Because we are geeks",
                            copyHeader: "We have all the fancy gadgets.",
                            copyBody: "Bluetooth, beacon, NFC, Augmented reality, IoT and more - we know and we have all these buzzwords in our office. We put Superman in AR before Pokemon Go did."
                        }]
                    }, (0, d.getLastArrayItem)(r.props.ui).headerUseBlackVar || r.props.headerUseBlackVar(!0), r
                }
                return function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                }(t, n.Component), a(t, [{
                    key: "componentDidMount",
                    value: function() {
                        var e = this;
                        this.props.initImagePreloading(this.servicesGridWrapper.current, "img", !1, function() {
                            e.setState({
                                hasComponentLoaded: !0
                            })
                        })
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this;
                        return o.default.createElement("section", {
                            className: "Services__mainWrapper"
                        }, o.default.createElement("section", {
                            className: "Services__copyWrapper"
                        }, o.default.createElement("p", {
                            className: "Services__mainHeader ServicesOnboardAnim__heroCopy"
                        }, "We build digital"), o.default.createElement("p", {
                            className: "Services__mainHeader ServicesOnboardAnim__heroCopy color--red"
                        }, "for a living."), o.default.createElement("p", {
                            className: "Services__bodyCopy ServicesOnboardAnim__bodyCopy"
                        }, "Codigo comprises a team of brilliant minds and innovative individuals who create digital products people love to use."), o.default.createElement("p", {
                            className: "Services__bodyCopy ServicesOnboardAnim__bodyCopy"
                        }, "We believe that seamless, user-centric and meaningful experiences transcend mediums and touchpoints.")), o.default.createElement("section", {
                            ref: this.servicesGridWrapper
                        }, o.default.createElement(s.default, {
                            minWidth: 760
                        }, function(t) {
                            return t ? o.default.createElement("section", {
                                className: "servicesGrid__mainWrapper"
                            }, e.data.services.map(function(t, a) {
                                return o.default.createElement("div", {
                                    key: a,
                                    className: e.state.hasComponentLoaded ? "servicesGrid__item" : "is--dNone"
                                }, o.default.createElement("div", {
                                    className: "serviceItem__mainWrapper"
                                }, o.default.createElement("div", {
                                    className: "serviceItem__ballBGWrapper"
                                }, o.default.createElement("div", {
                                    style: {
                                        backgroundColor: t.accentColor
                                    },
                                    className: "serviceItem__ballBG"
                                })), o.default.createElement("img", {
                                    className: "serviceItem__heroImg",
                                    src: r(248)("./" + t.img2x),
                                    srcSet: r(248)("./" + t.img) + " 1x, " + r(248)("./" + t.img2x) + " 2x"
                                }), o.default.createElement("div", {
                                    className: "serviceItem__wrapperHeader--preHover"
                                }, o.default.createElement("div", {
                                    className: "serviceItem__overflowHiddenWrapper"
                                }, o.default.createElement("p", {
                                    className: "serviceItem__headerCopy"
                                }, t.mainHeader))), o.default.createElement("div", {
                                    className: "serviceItem__wrapperSubHeader--preHover"
                                }, o.default.createElement("div", {
                                    className: "serviceItem__overflowHiddenWrapper"
                                }, o.default.createElement("p", {
                                    className: "serviceItem__subHeaderCopy"
                                }, t.mainSubHeader))), o.default.createElement("div", {
                                    className: "serviceItem__bodyContentWrapper"
                                }, o.default.createElement("div", {
                                    className: "serviceItem__wrapperHeader--postHover"
                                }, o.default.createElement("div", {
                                    className: "serviceItem__overflowHiddenWrapper"
                                }, o.default.createElement("p", {
                                    className: "serviceItem__headerCopy",
                                    style: {
                                        color: t.textColor
                                    }
                                }, t.mainHeader))), o.default.createElement("div", {
                                    className: "serviceItem__wrapperSubHeader--postHover"
                                }, o.default.createElement("div", {
                                    className: "serviceItem__overflowHiddenWrapper"
                                }, o.default.createElement("p", {
                                    className: "serviceItem__subHeaderCopy",
                                    style: {
                                        color: t.textColor
                                    }
                                }, t.copyHeader))), o.default.createElement("div", {
                                    className: "serviceItem__bodyCopy",
                                    style: {
                                        color: t.textColor
                                    },
                                    dangerouslySetInnerHTML: {
                                        __html: l.default.sanitize(t.copyBody)
                                    }
                                }))))
                            }), o.default.createElement("div", {
                                className: e.state.hasComponentLoaded ? "servicesGrid__item" : "is--dNone"
                            }, o.default.createElement("div", {
                                className: "serviceItem__mainWrapper"
                            }, o.default.createElement("div", {
                                className: "serviceItem__ballBGWrapper"
                            }, o.default.createElement("div", {
                                style: {
                                    backgroundColor: "#883955"
                                },
                                className: "serviceItem__ballBG"
                            })), o.default.createElement("img", {
                                className: "serviceItem__heroImg",
                                src: r(249),
                                srcSet: r(259) + " 1x, " + r(249) + " 2x"
                            }), o.default.createElement("div", {
                                className: "serviceItem__wrapperHeader--preHover"
                            }, o.default.createElement("div", {
                                className: "serviceItem__overflowHiddenWrapper"
                            }, o.default.createElement("p", {
                                className: "serviceItem__headerCopy"
                            }, "Coaching"))), o.default.createElement("div", {
                                className: "serviceItem__wrapperSubHeader--preHover"
                            }, o.default.createElement("div", {
                                className: "serviceItem__overflowHiddenWrapper"
                            }, o.default.createElement("p", {
                                className: "serviceItem__subHeaderCopy"
                            }, "Come learn our secrets"))), o.default.createElement("div", {
                                className: "serviceItem__bodyContentWrapper"
                            }, o.default.createElement("div", {
                                className: "serviceItem__wrapperHeader--postHover"
                            }, o.default.createElement("div", {
                                className: "serviceItem__overflowHiddenWrapper"
                            }, o.default.createElement("p", {
                                className: "serviceItem__headerCopy",
                                style: {
                                    color: "#fff"
                                }
                            }, "Coaching"))), o.default.createElement("div", {
                                className: "serviceItem__wrapperSubHeader--postHover"
                            }, o.default.createElement("div", {
                                className: "serviceItem__overflowHiddenWrapper"
                            }, o.default.createElement("p", {
                                className: "serviceItem__subHeaderCopy",
                                style: {
                                    color: "#fff"
                                }
                            }, "We’d love to share."))), o.default.createElement("div", {
                                className: "serviceItem__bodyCopy",
                                style: {
                                    color: "#fff"
                                }
                            }, o.default.createElement("p", null, "Attend our Masterclasses with the Codigo syllabus or talk to us to customise sessions just for your business teams."), o.default.createElement("a", {
                                onClick: function() {
                                    e.props.showCTAFormType("organise")
                                }
                            }, "Learn more here.")))))) : o.default.createElement("section", null, e.data.services.map(function(e, t) {
                                return o.default.createElement("div", {
                                    key: t,
                                    className: "responsiveServiceItem__mainWrapper"
                                }, o.default.createElement("p", {
                                    className: "responsiveServiceItem__subheader"
                                }, e.mainHeader), o.default.createElement("p", {
                                    className: "responsiveServiceItem__header"
                                }, e.copyHeader), o.default.createElement("div", {
                                    className: "responsiveServiceItem__ballBG",
                                    style: {
                                        backgroundColor: e.accentColor
                                    }
                                }, o.default.createElement("img", {
                                    className: "responsiveServiceItem__heroImg",
                                    src: r(248)("./" + e.img2x),
                                    srcSet: r(248)("./" + e.img) + " 1x, " + r(248)("./" + e.img2x) + " 2x"
                                })), o.default.createElement("p", {
                                    className: "responsiveServiceItem__body"
                                }, e.copyBody))
                            }), o.default.createElement("div", {
                                className: "responsiveServiceItem__mainWrapper"
                            }, o.default.createElement("p", {
                                className: "responsiveServiceItem__subheader"
                            }, "Coaching"), o.default.createElement("p", {
                                className: "responsiveServiceItem__header"
                            }, "We’d love to share."), o.default.createElement("div", {
                                className: "responsiveServiceItem__ballBG",
                                style: {
                                    backgroundColor: "#883955"
                                }
                            }, o.default.createElement("img", {
                                className: "responsiveServiceItem__heroImg",
                                src: r(249),
                                srcSet: r(259) + " 1x, " + r(249) + " 2x"
                            })), o.default.createElement("p", {
                                className: "responsiveServiceItem__body"
                            }, "Attend our Masterclasses with the Codigo syllabus or talk to us to customise sessions just for your business teams.", " ", o.default.createElement("a", {
                                onClick: function() {
                                    e.props.showCTAFormType("organise")
                                }
                            }, "Learn more here."))))
                        })))
                    }
                }]), t
            }();
            t.default = (0, i.connect)(function(e) {
                return {
                    ui: e.ui
                }
            }, function(e) {
                return {
                    headerUseBlackVar: (0, c.bindActionCreators)(m.headerUseBlackVar, e),
                    showCTAFormType: (0, c.bindActionCreators)(m.showCTAFormType, e)
                }
            })((0, p.default)(f))
        },
        248: function(e, t, r) {
            var a = {
                "./services-cogwheels.png": 312,
                "./services-cogwheels@2x.png": 311,
                "./services-laptop.png": 310,
                "./services-laptop@2x.png": 309,
                "./services-letterSeal.png": 308,
                "./services-letterSeal@2x.png": 307,
                "./services-phone.png": 306,
                "./services-phone@2x.png": 305,
                "./services-pixCherry.png": 304,
                "./services-pixCherry@2x.png": 303,
                "./services-postIt.png": 302,
                "./services-postIt@2x.png": 301,
                "./services-rolledCert.png": 259,
                "./services-rolledCert@2x.png": 249,
                "./services-vr.png": 300,
                "./services-vr@2x.png": 299
            };

            function n(e) {
                var t = o(e);
                return r(t)
            }

            function o(e) {
                var t = a[e];
                if (!(t + 1)) {
                    var r = new Error('Cannot find module "' + e + '".');
                    throw r.code = "MODULE_NOT_FOUND", r
                }
                return t
            }
            n.keys = function() {
                return Object.keys(a)
            }, n.resolve = o, e.exports = n, n.id = 248
        },
        249: function(e, t) {
            e.exports = "/img/_-_aqfF.png"
        },
        259: function(e, t) {
            e.exports = "/img/2iQNY9b.png"
        },
        299: function(e, t) {
            e.exports = "/img/2T6VKMl.png"
        },
        300: function(e, t) {
            e.exports = "/img/hLH8x3i.png"
        },
        301: function(e, t) {
            e.exports = "/img/2DKo_GI.png"
        },
        302: function(e, t) {
            e.exports = "/img/3ez9-6g.png"
        },
        303: function(e, t) {
            e.exports = "/img/2JUHtgq.png"
        },
        304: function(e, t) {
            e.exports = "/img/2bcMroq.png"
        },
        305: function(e, t) {
            e.exports = "/img/256r_Tk.png"
        },
        306: function(e, t) {
            e.exports = "/img/34LvMZU.png"
        },
        307: function(e, t) {
            e.exports = "/img/1dETdYI.png"
        },
        308: function(e, t) {
            e.exports = "/img/1TZkmTt.png"
        },
        309: function(e, t) {
            e.exports = "/img/11UqFo1.png"
        },
        310: function(e, t) {
            e.exports = "/img/2hkgtCe.png"
        },
        311: function(e, t) {
            e.exports = "/img/AB0fg7a.png"
        },
        312: function(e, t) {
            e.exports = "/img/2gthuKw.png"
        },
        313: function(e, t, r) {},
        314: function(e, t, r) {},
        315: function(e, t, r) {},
        316: function(e, t, r) {},
        317: function(e, t, r) {},
        318: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a, n = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var a in r) Object.prototype.hasOwnProperty.call(r, a) && (e[a] = r[a])
                    }
                    return e
                },
                o = function() {
                    function e(e, t) {
                        for (var r = 0; r < t.length; r++) {
                            var a = t[r];
                            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                        }
                    }
                    return function(t, r, a) {
                        return r && e(t.prototype, r), a && e(t, a), t
                    }
                }(),
                s = (a = r(1)) && a.__esModule ? a : {
                    default: a
                };

            function i(e, t) {
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !t || "object" != typeof t && "function" != typeof t ? e : t
            }
            t.default = function(e) {
                return function(t) {
                    function r() {
                        var e, t, a;
                        ! function(e, t) {
                            if (!(e instanceof r)) throw new TypeError("Cannot call a class as a function")
                        }(this);
                        for (var n = arguments.length, o = Array(n), s = 0; s < n; s++) o[s] = arguments[s];
                        return t = a = i(this, (e = r.__proto__ || Object.getPrototypeOf(r)).call.apply(e, [this].concat(o))), a.initImagePreloading = function(e, t, r, a) {
                            var n = 0,
                                o = e.querySelectorAll(t);
                            o.forEach(function(e) {
                                var t, s = new Image;
                                t = r ? (e.currentStyle || window.getComputedStyle(e, !1)).backgroundImage.slice(4, -1).replace(/"/g, "") : e.currentSrc ? e.currentSrc : e.src, s.src = t, s.addEventListener("load", function() {
                                    ++n == o.length - 1 && a && a()
                                }, !1)
                            })
                        }, i(a, t)
                    }
                    return function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                    }(r, s.default.Component), o(r, [{
                        key: "render",
                        value: function() {
                            return s.default.createElement(e, n({}, this.props, {
                                initImagePreloading: this.initImagePreloading
                            }))
                        }
                    }]), r
                }()
            }
        }
    }
]);
//# sourceMappingURL=6.22cc44f0bd576b7ccb23.js.map